part of 'register_cubit.dart';

@immutable
sealed class RegisterState {}

final class RegisterInitial extends RegisterState {}
final class RegisterLoading extends RegisterState {}
final class RegisterFailure extends RegisterState {
  final String message;
  RegisterFailure(this.message);
}
final class RegisterSuccess extends RegisterState {
  final UserEntity userEntity;
  RegisterSuccess(this.userEntity);
}
