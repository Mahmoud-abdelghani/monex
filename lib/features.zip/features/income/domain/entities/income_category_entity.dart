class IncomeCategoryEntity {
  final int id;
  final String name;
  final String icon;
  IncomeCategoryEntity({
    required this.id,
    required this.name,
    required this.icon,
  });
}