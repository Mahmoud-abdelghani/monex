import 'package:monex/features/income/domain/entities/income_category_entity.dart';

class IncomeEntity {
  final String id;
  final String title;
  final double amount;
  final IncomeCategoryEntity category;
  final String date;

  IncomeEntity({
    required this.id,
    required this.title,
    required this.amount,
    required this.category,
    required this.date,
  });
}
