import 'package:monex/features/expense/domain/entities/expense_category_entity.dart';

class ExpenseEntity {
  final String id;
  final String title;
  final double amount;
  final ExpenseCategoryEntity category;
  final DateTime date;
  ExpenseEntity({
    required this.id,
    required this.title,
    required this.amount,
    required this.category,
    required this.date,
  });

}