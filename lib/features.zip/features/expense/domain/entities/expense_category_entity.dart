class ExpenseCategoryEntity {
  final int id;
  final String name;
  final String icon;
  ExpenseCategoryEntity({
    required this.id,
    required this.name,
    required this.icon,
  });
}